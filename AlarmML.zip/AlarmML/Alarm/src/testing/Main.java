package testing;
import java.text.DecimalFormat;
import java.util.HashMap; 
import java.util.Map; 
import java.util.Set;

import static testing.Data.Alarm;

public class Main{

	
	// two hashmap 
	// one for value extraction from dataset and calculcation
	// one for node connection for forward chaining
	
  // integer help to display data order wise because hashmap
 // itself is unordered data structure
  static HashMap<Integer, String[][]> map = new HashMap<Integer, String[][]>();
  
  static HashMap<String, Double> hm = new HashMap<String, Double>();
  
  
  public static void main(String[] args) {
       
       double trueCounter=0,true_john=0,true_mary=0,false_earth_count=0;      
       DecimalFormat df = new DecimalFormat("####0.00");
        for(int i=0;i<5;i++){
            for(int j=1;j<12;j++){
                if(Alarm[j][i].equalsIgnoreCase("True")){
                    trueCounter++;
                }              
            }
            double cal=trueCounter/11.0;
           
            // check both Burglary(B) and Earthquake(E) are true 
            if(i == 2){
            	
            	    trueCounter=0;
                    for(int both=1;both<12;both++){
                        if(Alarm[both][0].equalsIgnoreCase("True") && Alarm[both][1].equalsIgnoreCase("True") ){
                            trueCounter++;
                            
                        }
                        
                        // this  will count total true of Burglary(B) and false of earthquake
                        if(Alarm[both][0].equalsIgnoreCase("True") && Alarm[both][1].equalsIgnoreCase("False") ){
                        	false_earth_count++;
                            
                        }
                        
                    }
                  
                  // probability calculation
                  double cal2=trueCounter/11.0;
                  
             
                  //  p(a|b,-e) simple probability calculation
                  double cal5=false_earth_count/11.0;
                  
                  
                  
                  // adding to hashmap
                  hm.put(Alarm[0][i], new Double(df.format(cal2)));
              	  
                 
              	  
                  hm.put("P(Alarm|B,-E)", new Double(df.format(cal5)));
              	  
                  double ne = 1 - hm.get("P(Alarm|B,-E)");
              	
                  hm.put("P(-Alarm|B,-E)", new Double(df.format(ne)));
                   
            }
            else{
            	  hm.put(Alarm[0][i], new Double(df.format(cal)));
            	  trueCounter=0;
            }
            
          
        }
        // to get false values for each node
        double i = 1-hm.get("P(Alarm|B,E)");
        double e = 1- hm.get("Earthquake(E)");
        double j = 1-hm.get("JohnCalls(J)");
        double m = 1-hm.get("MaryCalls(M)");
        
        //  DecimalFormat  is used for decimal round off
        DecimalFormat dff = new DecimalFormat("#.##");
        m = new Double (dff.format(m));
        
        hm.put("JohnCalls(-J)", j);
        hm.put("MaryCalls(-M)", m);
        hm.put("P(-Alarm|B,E)", new Double (dff.format(i)));
        hm.put("Earthquake(-E)", new Double (dff.format(e)));
        // to print all values in hash map
        Set<Map.Entry<String, Double>> set = hm.entrySet();
         for (Map.Entry<String, Double> me : set) {
            System.out.print(me.getKey() + ": ");
            System.out.println(me.getValue());
 
        }
         
        		System.out.println(set);
                    
            
            // you can get any value by using column name like this below
            double value = hm.get("Earthquake(E)");
            System.out.println(value);

           // nodes should be connected properly structure wise
            // tree shape (parent or child concept)
            // first column of 2d string array contain parent
            // second column of 2d string array contain child
            
            connect_nodes(1, new String[][]{{"Burglary(B)"},{"Earthquake(E)","Earthquake(-E)"}});
            connect_nodes(2, new String[][]{{"Earthquake(E)"},{"P(Alarm|B,E)","P(-Alarm|B,E)"}});
            connect_nodes(3, new String[][]{{"Earthquake(-E)"},{"P(Alarm|B,-E)","P(-Alarm|B,-E)"}});
            connect_nodes(4, new String[][]{{"P(Alarm|B,E)"},{"JohnCalls(J)"}});
            connect_nodes(5, new String[][]{{"P(-Alarm|B,E)"},{"JohnCalls(-J)"}});
            connect_nodes(6, new String[][]{{"P(Alarm|B,-E))"},{"JohnCalls(J)"}});
            connect_nodes(7, new String[][]{{"P(-Alarm|B,-E)"},{"JohnCalls(-J)"}});
            connect_nodes(8, new String[][]{{"JohnCalls(J)"},{"MaryCalls(M)"}});
            connect_nodes(9, new String[][]{{"JohnCalls(-J)"},{"MaryCalls(-M)"}});
            connect_nodes(10, new String[][]{{"JohnCalls(J)"},{"MaryCalls(M)"}});
            connect_nodes(11, new String[][]{{"JohnCalls(-J)"},{"MaryCalls(-M)"}});
            
           // display all nodes connected through hashmap
           show_connected_nodes();


    }



    public static void connect_nodes(int num , String[][] parent_child ){

      // store in hashmap
      map.put(num ,parent_child);

    }



    public static void show_connected_nodes(){

    //Forward chaining is the logical process of inferring unknown truths from 
    	//known data 
  //and moving forward using determined conditions and rules to find a solution
    	
            System.out.println("Forward chain");
            int i =0;
            for (Map.Entry<Integer, String[][]> entry : map.entrySet()) {
                int key = entry.getKey();
                String[][] value = entry.getValue();
              
              // this code for display
              // i simply take data from hashmap ( map ) and get value from hashmap ( hm )
              if(value[1].length <2){
               System.out.println(value[0][0]+" = "+hm.get(value[0][0])+" : "+value[1][0]+" = "+hm.get(value[1][0]) );
               }
               else{
                   System.out.println(value[0][0]+" = "+hm.get(value[0][0])+" : "+value[1][0]+" = "+hm.get(value[1][0])+" , "+value[1][1]+" = "+hm.get(value[1][1]));     
               }
            }
              
            
         

            	

    }
    
    
  


    
}




class Data {
    static String[][] Alarm ={
                       {"Burglary(B)","Earthquake(E)","P(Alarm|B,E)","MaryCalls(M)","JohnCalls(J)"},
		 	{"True",		"False",		"False",		"True",		"False"},
		 	{"True",		"True",			"False",		"True",		"False"},
		 	{"False",		"False",		"True",			"True",		"False"},
		 	{"True",		"True",			"False",		"False",	"True"},
		 	{"False",		"False",		"False",		"True",		"False"},
		 	{"False",		"True",			"False",		"False",	"True"},
		 	{"False",		"True",			"True",			"True",		"True"},
		 	{"False",		"False",		"True",			"False",	"True"},
		 	{"True",		"False",		"False",		"True",		"False"},
		 	{"True",		"False",		"True",			"True",		"True"},
		 	{"True",		"False",		"False",		"True",		"False"}
    };

}

