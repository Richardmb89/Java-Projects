package testing;


import java.text.DecimalFormat;
import java.util.HashMap; 
import java.util.Map; 
import java.util.Set;

import static testing.Data.Alarm;

public class Main {

    
    public static void main(String[] args) {
       HashMap<String, Double> hm = new HashMap<String, Double>();
       double trueCounter=0;      
       DecimalFormat df = new DecimalFormat("####0.00");
        for(int i=0;i<5;i++){
            for(int j=1;j<12;j++){
                if(Alarm[j][i].equalsIgnoreCase("True")){
                    trueCounter++;
                }              
            }
            double cal=trueCounter/11.0;
            hm.put(Alarm[0][i], new Double(df.format(cal)));
            trueCounter=0;
        }
        
        // to print all values in hash map
        Set<Map.Entry<String, Double>> set = hm.entrySet();
         for (Map.Entry<String, Double> me : set) {
            System.out.print(me.getKey() + ": ");
            System.out.println(me.getValue());
 
        }
                    
            
            // you can get any value by using column name like this below
            double value = hm.get("Earthquake(E)");
            System.out.println(value);
    }
    
}
 class Data {
     static String[][] Alarm ={
                        {"Burglary(B)","Earthquake(E)","P(Alarm|B,E)","MaryCalls(M)","JohnCalls(J)"},
		 	{"True",		"False",		"False",		"True",		"False"},
		 	{"True",		"True",			"False",		"True",		"False"},
		 	{"False",		"False",		"True",			"True",		"False"},
		 	{"True",		"True",			"False",		"False",	"True"},
		 	{"False",		"False",		"False",		"True",		"False"},
		 	{"False",		"True",			"False",		"False",	"True"},
		 	{"False",		"True",			"True",			"True",		"True"},
		 	{"False",		"False",		"True",			"False",	"True"},
		 	{"True",		"False",		"False",		"True",		"False"},
		 	{"True",		"False",		"True",			"True",		"True"},
		 	{"True",		"False",		"False",		"True",		"False"}
     };

}



 
